import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertSessionSchema, insertKeySchema } from "@shared/schema";
import { randomBytes } from "crypto";

// Middleware to get client IP - use socket address to prevent spoofing
function getClientIp(req: Request): string {
  return req.socket.remoteAddress || req.ip || '127.0.0.1';
}

// Generate a random key in format RBX-XXXX-XXXX-XXXX
function generateKey(): string {
  const segments = Array.from({ length: 4 }, () => {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    return Array.from({ length: 4 }, () => 
      chars[Math.floor(Math.random() * chars.length)]
    ).join("");
  });
  return `RBX-${segments.join("-")}`;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Get or create session for current IP
  app.get("/api/session", async (req, res) => {
    try {
      const ipAddress = getClientIp(req);
      
      let session = await storage.getSessionByIp(ipAddress);
      
      if (!session) {
        session = await storage.createSession({
          ipAddress,
          progress: 0,
        });
      }
      
      res.json(session);
    } catch (error) {
      console.error("Error getting session:", error);
      res.status(500).json({ error: "Failed to get session" });
    }
  });

  // Advance session progress
  app.post("/api/session/progress", async (req, res) => {
    try {
      const ipAddress = getClientIp(req);
      const session = await storage.getSessionByIp(ipAddress);
      
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      
      const newProgress = Math.min(session.progress + 1, 2);
      const updated = await storage.updateSessionProgress(session.id, newProgress);
      
      res.json(updated);
    } catch (error) {
      console.error("Error updating progress:", error);
      res.status(500).json({ error: "Failed to update progress" });
    }
  });

  // Generate a new key
  app.post("/api/keys", async (req, res) => {
    try {
      const ipAddress = getClientIp(req);
      const session = await storage.getSessionByIp(ipAddress);
      
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      
      // Check if progress is complete
      if (session.progress < 2) {
        return res.status(400).json({ error: "Complete verification steps first" });
      }
      
      // Check key limit (5 keys per IP)
      const activeKeyCount = await storage.getActiveKeyCountByIp(ipAddress);
      if (activeKeyCount >= 5) {
        return res.status(400).json({ error: "Maximum key limit reached" });
      }
      
      // Generate unique key
      let keyValue = generateKey();
      let existing = await storage.getKeyByValue(keyValue);
      
      // Ensure uniqueness
      while (existing) {
        keyValue = generateKey();
        existing = await storage.getKeyByValue(keyValue);
      }
      
      // Create key with 24 hour expiration
      const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);
      
      const key = await storage.createKey({
        sessionId: session.id,
        key: keyValue,
        expiresAt,
      });
      
      // Reset session progress
      await storage.updateSessionProgress(session.id, 0);
      
      res.json(key);
    } catch (error) {
      console.error("Error creating key:", error);
      res.status(500).json({ error: "Failed to create key" });
    }
  });

  // Get all keys for current session
  app.get("/api/keys", async (req, res) => {
    try {
      const ipAddress = getClientIp(req);
      const session = await storage.getSessionByIp(ipAddress);
      
      if (!session) {
        return res.json([]);
      }
      
      const keys = await storage.getKeysBySessionId(session.id);
      res.json(keys);
    } catch (error) {
      console.error("Error getting keys:", error);
      res.status(500).json({ error: "Failed to get keys" });
    }
  });

  // Delete a key - verify ownership
  app.delete("/api/keys/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const ipAddress = getClientIp(req);
      
      // Get the key to verify ownership
      const keyToDelete = await storage.getKeyById(id);
      
      if (!keyToDelete) {
        return res.status(404).json({ error: "Key not found" });
      }
      
      // Get the session that owns this key
      const keySession = await storage.getSessionById(keyToDelete.sessionId);
      
      if (!keySession || keySession.ipAddress !== ipAddress) {
        return res.status(403).json({ error: "Unauthorized to delete this key" });
      }
      
      await storage.deleteKey(id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting key:", error);
      res.status(500).json({ error: "Failed to delete key" });
    }
  });

  // Validate a key (for Roblox scripts)
  app.post("/api/keys/validate", async (req, res) => {
    try {
      const { key } = req.body;
      
      // Validate request body
      if (!key || typeof key !== 'string') {
        return res.status(400).json({ 
          valid: false, 
          error: "Valid key string is required" 
        });
      }
      
      // Prevent excessively long keys
      if (key.length > 500) {
        return res.status(400).json({ 
          valid: false, 
          error: "Invalid key format" 
        });
      }
      
      const keyData = await storage.getKeyByValue(key);
      
      if (!keyData) {
        return res.json({ 
          valid: false, 
          error: "Key not found" 
        });
      }
      
      // Check if key is expired
      if (keyData.expiresAt <= new Date()) {
        return res.json({ 
          valid: false, 
          error: "Key has expired" 
        });
      }
      
      res.json({ 
        valid: true,
        expiresAt: keyData.expiresAt,
      });
    } catch (error) {
      console.error("Error validating key:", error);
      res.status(500).json({ 
        valid: false, 
        error: "Failed to validate key" 
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
