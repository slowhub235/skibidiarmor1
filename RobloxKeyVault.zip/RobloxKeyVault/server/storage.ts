import { type Session, type InsertSession, type Key, type InsertKey } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Session operations
  getSessionByIp(ipAddress: string): Promise<Session | undefined>;
  getSessionById(sessionId: string): Promise<Session | undefined>;
  createSession(session: InsertSession): Promise<Session>;
  updateSessionProgress(sessionId: string, progress: number): Promise<Session | undefined>;
  
  // Key operations
  createKey(key: InsertKey): Promise<Key>;
  getKeyById(keyId: string): Promise<Key | undefined>;
  getKeyByValue(keyValue: string): Promise<Key | undefined>;
  getKeysBySessionId(sessionId: string): Promise<Key[]>;
  deleteKey(keyId: string): Promise<void>;
  getActiveKeyCountByIp(ipAddress: string): Promise<number>;
  cleanupExpiredKeys(): Promise<void>;
}

export class MemStorage implements IStorage {
  private sessions: Map<string, Session>;
  private keys: Map<string, Key>;

  constructor() {
    this.sessions = new Map();
    this.keys = new Map();
    
    // Cleanup expired keys every 5 minutes
    setInterval(() => {
      this.cleanupExpiredKeys();
    }, 5 * 60 * 1000);
  }

  async getSessionByIp(ipAddress: string): Promise<Session | undefined> {
    return Array.from(this.sessions.values()).find(
      (session) => session.ipAddress === ipAddress,
    );
  }

  async getSessionById(sessionId: string): Promise<Session | undefined> {
    return this.sessions.get(sessionId);
  }

  async createSession(insertSession: InsertSession): Promise<Session> {
    const id = randomUUID();
    const session: Session = {
      ...insertSession,
      progress: insertSession.progress ?? 0,
      id,
      createdAt: new Date(),
    };
    this.sessions.set(id, session);
    return session;
  }

  async updateSessionProgress(sessionId: string, progress: number): Promise<Session | undefined> {
    const session = this.sessions.get(sessionId);
    if (!session) return undefined;
    
    const updated = { ...session, progress };
    this.sessions.set(sessionId, updated);
    return updated;
  }

  async createKey(insertKey: InsertKey): Promise<Key> {
    const id = randomUUID();
    const key: Key = {
      ...insertKey,
      id,
      createdAt: new Date(),
    };
    this.keys.set(id, key);
    return key;
  }

  async getKeyById(keyId: string): Promise<Key | undefined> {
    return this.keys.get(keyId);
  }

  async getKeyByValue(keyValue: string): Promise<Key | undefined> {
    return Array.from(this.keys.values()).find(
      (key) => key.key === keyValue,
    );
  }

  async getKeysBySessionId(sessionId: string): Promise<Key[]> {
    return Array.from(this.keys.values()).filter(
      (key) => key.sessionId === sessionId,
    );
  }

  async deleteKey(keyId: string): Promise<void> {
    this.keys.delete(keyId);
  }

  async getActiveKeyCountByIp(ipAddress: string): Promise<number> {
    const session = await this.getSessionByIp(ipAddress);
    if (!session) return 0;
    
    const sessionKeys = await this.getKeysBySessionId(session.id);
    const now = new Date();
    
    return sessionKeys.filter(key => key.expiresAt > now).length;
  }

  async cleanupExpiredKeys(): Promise<void> {
    const now = new Date();
    const expiredKeys = Array.from(this.keys.values()).filter(
      (key) => key.expiresAt <= now,
    );
    
    expiredKeys.forEach((key) => {
      this.keys.delete(key.id);
    });
    
    console.log(`Cleaned up ${expiredKeys.length} expired keys`);
  }
}

export const storage = new MemStorage();
