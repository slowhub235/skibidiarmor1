# Roblox Key System

## Overview

This is a Roblox key system website that provides secure key generation and verification for Roblox scripts. The application uses a freemium model where users can generate time-limited verification keys after completing progress steps. It features IP-based session management, key tracking with expiration, and a gaming-inspired dark-mode UI built with modern web technologies.

The system follows a utility-first approach - prioritizing clarity and performance over flashy aesthetics while maintaining subtle gaming DNA through its design language.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React 18+ with TypeScript, built using Vite for fast development and optimized production builds.

**UI Component Library**: Shadcn/ui with Radix UI primitives, providing accessible, composable components styled with Tailwind CSS. The design system uses the "new-york" style variant with dark-mode as the default.

**State Management**: 
- TanStack Query (React Query) for server state management with automatic caching and refetching
- React hooks for local component state
- LocalStorage for privacy acceptance persistence

**Routing**: Wouter for lightweight client-side routing (currently single-page with Home route and 404 fallback).

**Styling Approach**: 
- Tailwind CSS with custom design tokens defined in CSS variables
- Dark-first color scheme based on gaming aesthetics (Discord/Stripe-inspired)
- Custom HSL color system for theming with Material Design principles adapted for gaming
- Typography: Inter for UI, JetBrains Mono for technical data (keys, IPs, codes)

**Design Philosophy**: The UI balances professional utility with gaming aesthetics - trustworthy key management that feels native to the gaming ecosystem without being overly stylized.

### Backend Architecture

**Server Framework**: Express.js running on Node.js with TypeScript for type safety.

**API Design**: RESTful JSON API with the following endpoints:
- `GET /api/session` - Retrieve or create session based on client IP
- `POST /api/session/progress` - Advance session progress
- `POST /api/keys` - Generate new key after completing progress
- `GET /api/keys` - Retrieve all keys for current session
- `DELETE /api/keys/:id` - Delete a specific key

**Session Management**: IP-based session tracking to prevent abuse. Client IP is extracted from socket remote address to prevent spoofing via headers.

**Key Generation**: Custom algorithm generating keys in format `RBX-XXXX-XXXX-XXXX` using random alphanumeric characters.

**Business Logic**:
- Maximum 5 keys per IP address (freemium limit)
- Keys expire after a set duration
- 2-step progress system required before key generation
- Automatic cleanup of expired keys via interval-based background task

### Data Storage

**ORM**: Drizzle ORM for type-safe database operations with PostgreSQL dialect.

**Storage Implementation**: Dual storage strategy:
- **Development/Testing**: In-memory storage (`MemStorage` class) using JavaScript Maps
- **Production**: PostgreSQL database via Neon serverless driver

**Database Schema**:
- `sessions` table: Tracks user sessions with IP address, progress counter, and creation timestamp
- `keys` table: Stores generated keys with session reference, expiration timestamp, and unique key value
- Foreign key relationship: keys reference sessions with cascade delete

**Data Models**: 
- Zod schemas for runtime validation using `drizzle-zod`
- TypeScript types inferred from Drizzle schema definitions
- Insert schemas omit auto-generated fields (id, timestamps)

**Rationale**: The dual storage approach allows rapid development without database dependencies while maintaining production-ready PostgreSQL support. Drizzle provides excellent TypeScript integration and developer experience compared to traditional ORMs.

### External Dependencies

**Database**: 
- PostgreSQL (via Neon serverless driver `@neondatabase/serverless`)
- Drizzle Kit for migrations and schema management
- Connection string via `DATABASE_URL` environment variable

**UI Libraries**:
- Radix UI (comprehensive set of accessible primitives for dialogs, popovers, dropdowns, etc.)
- Lucide React for icons
- Embla Carousel for carousel functionality
- CMDK for command menu interface
- React Hook Form with Zod resolvers for form validation
- Date-fns for date manipulation

**Development Tools**:
- Vite with React plugin for development server and builds
- ESBuild for server bundling
- TSX for TypeScript execution in development
- Replit-specific plugins for runtime error overlay and dev tooling

**Fonts**: Google Fonts (Inter and JetBrains Mono) loaded via CDN in index.html.

**Session Storage**: Connect-pg-simple for production PostgreSQL session storage (though currently using IP-based sessions without traditional session middleware).

**Styling**: 
- Tailwind CSS with PostCSS and Autoprefixer
- Class Variance Authority (CVA) for component variant management
- CLSX and tailwind-merge for className utilities

**Type Safety**: Full TypeScript coverage across frontend, backend, and shared code with strict mode enabled and path aliases for clean imports.