import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import Header from "@/components/Header";
import PrivacyModal from "@/components/PrivacyModal";
import KeyGenerationCard from "@/components/KeyGenerationCard";
import KeysTable, { KeyData } from "@/components/KeysTable";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { Session, Key } from "@shared/schema";

export default function Home() {
  const [privacyAccepted, setPrivacyAccepted] = useState(false);
  
  const maxKeys = 5;
  
  useEffect(() => {
    const accepted = localStorage.getItem("privacyAccepted");
    if (accepted === "true") {
      setPrivacyAccepted(true);
    }
  }, []);
  
  // Fetch session data
  const { data: session } = useQuery<Session>({
    queryKey: ["/api/session"],
    enabled: privacyAccepted,
  });
  
  // Fetch keys
  const { data: keys = [] } = useQuery<Key[]>({
    queryKey: ["/api/keys"],
    enabled: privacyAccepted,
  });
  
  // Advance progress mutation
  const advanceProgressMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/session/progress");
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/session"] });
    },
  });
  
  // Generate key mutation
  const generateKeyMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/keys");
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/keys"] });
      queryClient.invalidateQueries({ queryKey: ["/api/session"] });
    },
  });
  
  // Delete key mutation
  const deleteKeyMutation = useMutation({
    mutationFn: async (keyId: string) => {
      const res = await apiRequest("DELETE", `/api/keys/${keyId}`);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/keys"] });
    },
  });
  
  const handleAcceptPrivacy = () => {
    localStorage.setItem("privacyAccepted", "true");
    setPrivacyAccepted(true);
  };
  
  const handleStartGeneration = async () => {
    if (!session) return;
    
    if (session.progress === 0) {
      // First step: advance progress
      await advanceProgressMutation.mutateAsync();
    } else if (session.progress === 1) {
      // Second step: advance progress to 2, then generate key
      await advanceProgressMutation.mutateAsync();
      setTimeout(async () => {
        await generateKeyMutation.mutateAsync();
      }, 1000);
    }
  };
  
  const handleDeleteKey = (id: string) => {
    deleteKeyMutation.mutate(id);
  };
  
  // Transform keys to match KeysTable interface
  const transformedKeys: KeyData[] = keys.map((key) => {
    const expiresAt = new Date(key.expiresAt);
    const now = new Date();
    const timeLeft = expiresAt.getTime() - now.getTime();
    const hoursLeft = timeLeft / (1000 * 60 * 60);
    
    let status: KeyData["status"] = "active";
    if (timeLeft <= 0) {
      status = "expired";
    } else if (hoursLeft < 2) {
      status = "expiring";
    }
    
    return {
      id: key.id,
      key: key.key,
      expiresAt,
      status,
    };
  });
  
  const isGenerating = advanceProgressMutation.isPending || generateKeyMutation.isPending;
  
  return (
    <div className="min-h-screen bg-background">
      <PrivacyModal 
        open={!privacyAccepted} 
        onAccept={handleAcceptPrivacy}
      />
      
      <Header 
        ipAddress={session?.ipAddress || "Loading..."}
        keyCount={transformedKeys.filter(k => k.status !== "expired").length}
        maxKeys={maxKeys}
      />
      
      <main className="max-w-6xl mx-auto px-4 md:px-6 lg:px-8 py-8 md:py-12">
        <div className="space-y-8">
          <div className="max-w-2xl mx-auto">
            <KeyGenerationCard
              progress={session?.progress || 0}
              totalSteps={2}
              isGenerating={isGenerating}
              onStartGeneration={handleStartGeneration}
            />
          </div>
          
          <div className="max-w-4xl mx-auto">
            <KeysTable keys={transformedKeys} onDeleteKey={handleDeleteKey} />
          </div>
        </div>
      </main>
      
      <footer className="border-t border-border mt-16 py-8">
        <div className="max-w-6xl mx-auto px-4 md:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
            <p>&copy; 2025 Roblox Key System. All rights reserved.</p>
            <button 
              onClick={() => setPrivacyAccepted(false)}
              className="hover:text-foreground transition-colors"
              data-testid="link-privacy"
            >
              Privacy Policy
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
