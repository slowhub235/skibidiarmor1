import { useState } from 'react';
import KeyGenerationCard from '../KeyGenerationCard';

export default function KeyGenerationCardExample() {
  const [progress, setProgress] = useState(0);
  const [isGenerating, setIsGenerating] = useState(false);
  
  const handleStart = () => {
    console.log('Starting key generation process');
    setIsGenerating(true);
    
    setTimeout(() => {
      setIsGenerating(false);
      setProgress(prev => Math.min(prev + 1, 2));
    }, 1500);
  };
  
  return (
    <div className="p-8 max-w-2xl">
      <KeyGenerationCard 
        progress={progress}
        totalSteps={2}
        isGenerating={isGenerating}
        onStartGeneration={handleStart}
      />
    </div>
  );
}
