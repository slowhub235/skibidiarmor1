import Header from '../Header';

export default function HeaderExample() {
  return <Header ipAddress="195.64.125.21" keyCount={2} maxKeys={5} />;
}
