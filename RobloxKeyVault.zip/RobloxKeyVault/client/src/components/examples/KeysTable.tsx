import { useState } from 'react';
import KeysTable, { KeyData } from '../KeysTable';

export default function KeysTableExample() {
  const [keys, setKeys] = useState<KeyData[]>([
    {
      id: '1',
      key: 'RBX-A7F2-9D4E-1C8B',
      expiresAt: new Date(Date.now() + 2 * 60 * 60 * 1000),
      status: 'active',
    },
    {
      id: '2',
      key: 'RBX-3K9L-5M2P-7N4Q',
      expiresAt: new Date(Date.now() + 25 * 60 * 1000),
      status: 'expiring',
    },
  ]);
  
  const handleDelete = (id: string) => {
    console.log('Deleting key:', id);
    setKeys(prev => prev.filter(k => k.id !== id));
  };
  
  return (
    <div className="p-8 max-w-4xl">
      <KeysTable keys={keys} onDeleteKey={handleDelete} />
    </div>
  );
}
