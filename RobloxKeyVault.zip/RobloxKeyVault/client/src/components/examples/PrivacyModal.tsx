import { useState } from 'react';
import PrivacyModal from '../PrivacyModal';
import { Button } from '@/components/ui/button';

export default function PrivacyModalExample() {
  const [open, setOpen] = useState(true);
  
  return (
    <div className="p-8">
      <Button onClick={() => setOpen(true)} data-testid="button-show-privacy">
        Show Privacy Modal
      </Button>
      <PrivacyModal 
        open={open} 
        onAccept={() => {
          console.log('Privacy policy accepted');
          setOpen(false);
        }} 
      />
    </div>
  );
}
