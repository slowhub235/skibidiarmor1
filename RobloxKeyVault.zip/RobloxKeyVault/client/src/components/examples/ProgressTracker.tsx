import { useState } from 'react';
import ProgressTracker from '../ProgressTracker';
import { Button } from '@/components/ui/button';

export default function ProgressTrackerExample() {
  const [progress, setProgress] = useState(0);
  
  return (
    <div className="p-8 max-w-md">
      <ProgressTracker current={progress} total={2} />
      <div className="flex gap-2 mt-4">
        <Button onClick={() => setProgress(0)} size="sm" data-testid="button-reset">Reset</Button>
        <Button onClick={() => setProgress(1)} size="sm" data-testid="button-step1">Step 1</Button>
        <Button onClick={() => setProgress(2)} size="sm" data-testid="button-step2">Step 2</Button>
      </div>
    </div>
  );
}
