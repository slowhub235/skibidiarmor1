import { Key } from "lucide-react";

interface HeaderProps {
  ipAddress: string;
  keyCount: number;
  maxKeys: number;
}

export default function Header({ ipAddress, keyCount, maxKeys }: HeaderProps) {
  return (
    <header className="border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="max-w-6xl mx-auto px-4 md:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <div className="bg-primary/10 p-2 rounded-md">
              <Key className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-lg font-semibold text-foreground">Roblox Key System</h1>
              <p className="text-xs text-muted-foreground">Freemium</p>
            </div>
          </div>
          
          <div className="flex items-center gap-6">
            <div className="text-right">
              <p className="text-xs text-muted-foreground">Keys</p>
              <p className="text-sm font-medium text-foreground">
                {keyCount}/{maxKeys}
              </p>
            </div>
            <div className="text-right">
              <p className="text-xs text-muted-foreground">IP</p>
              <p className="text-sm font-mono text-foreground">{ipAddress}</p>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
