import { CheckCircle2, Circle } from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface ProgressTrackerProps {
  current: number;
  total: number;
}

export default function ProgressTracker({ current, total }: ProgressTrackerProps) {
  const percentage = (current / total) * 100;
  
  const steps = Array.from({ length: total }, (_, i) => ({
    step: i + 1,
    completed: i < current,
  }));

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium text-foreground">Progress</h3>
        <span className="text-2xl font-bold text-foreground">
          {current}/{total}
        </span>
      </div>
      
      <Progress value={percentage} className="h-2" data-testid="progress-bar" />
      
      <div className="flex items-center justify-between pt-2">
        {steps.map((step, index) => (
          <div key={step.step} className="flex items-center">
            <div className="flex flex-col items-center">
              {step.completed ? (
                <CheckCircle2 className="w-6 h-6 text-chart-2" data-testid={`step-${step.step}-completed`} />
              ) : (
                <Circle className="w-6 h-6 text-muted-foreground" data-testid={`step-${step.step}-pending`} />
              )}
              <span className="text-xs text-muted-foreground mt-1">
                Step {step.step}
              </span>
            </div>
            {index < steps.length - 1 && (
              <div className="w-8 md:w-16 h-0.5 bg-border mx-2 mb-6" />
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
