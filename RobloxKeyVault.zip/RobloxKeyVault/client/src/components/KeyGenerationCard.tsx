import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Loader2 } from "lucide-react";
import ProgressTracker from "./ProgressTracker";

interface KeyGenerationCardProps {
  progress: number;
  totalSteps: number;
  isGenerating: boolean;
  onStartGeneration: () => void;
}

export default function KeyGenerationCard({
  progress,
  totalSteps,
  isGenerating,
  onStartGeneration,
}: KeyGenerationCardProps) {
  const canGenerate = progress === 0;
  
  return (
    <Card className="border-primary/20 shadow-xl">
      <CardHeader>
        <CardTitle className="text-2xl">Generate New Key</CardTitle>
        <CardDescription>
          Complete the verification steps to receive your key
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <ProgressTracker current={progress} total={totalSteps} />
        
        {canGenerate ? (
          <Button 
            onClick={onStartGeneration}
            disabled={isGenerating}
            className="w-full h-12 text-base"
            data-testid="button-start-generation"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Processing...
              </>
            ) : (
              <>
                <Plus className="w-4 h-4 mr-2" />
                START
              </>
            )}
          </Button>
        ) : (
          <Button 
            onClick={onStartGeneration}
            disabled={isGenerating}
            className="w-full h-12 text-base"
            data-testid="button-get-key"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Generating Key...
              </>
            ) : (
              <>
                <Plus className="w-4 h-4 mr-2" />
                GET A NEW KEY
              </>
            )}
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
