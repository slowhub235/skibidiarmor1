import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Copy, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export interface KeyData {
  id: string;
  key: string;
  expiresAt: Date;
  status: "active" | "expiring" | "expired";
}

interface KeysTableProps {
  keys: KeyData[];
  onDeleteKey: (id: string) => void;
}

export default function KeysTable({ keys, onDeleteKey }: KeysTableProps) {
  const { toast } = useToast();
  
  const copyToClipboard = (key: string) => {
    navigator.clipboard.writeText(key);
    toast({
      title: "Copied!",
      description: "Key copied to clipboard",
    });
  };
  
  const getTimeRemaining = (expiresAt: Date) => {
    const now = new Date();
    const diff = expiresAt.getTime() - now.getTime();
    
    if (diff <= 0) return "Expired";
    
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    
    if (hours > 0) {
      return `${hours}h ${minutes}m`;
    }
    return `${minutes}m`;
  };
  
  const getStatusBadge = (status: KeyData["status"]) => {
    const variants = {
      active: { label: "Active", className: "bg-chart-2/20 text-chart-2 border-chart-2/30" },
      expiring: { label: "Expiring Soon", className: "bg-chart-4/20 text-chart-4 border-chart-4/30" },
      expired: { label: "Expired", className: "bg-destructive/20 text-destructive border-destructive/30" },
    };
    
    const variant = variants[status];
    
    return (
      <Badge variant="outline" className={variant.className} data-testid={`status-${status}`}>
        {variant.label}
      </Badge>
    );
  };
  
  if (keys.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Active Keys</CardTitle>
          <CardDescription>Your generated keys will appear here</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-12">
            <p className="text-muted-foreground">No keys generated yet</p>
            <p className="text-sm text-muted-foreground mt-2">
              Generate a new key to get started
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Active Keys</CardTitle>
        <CardDescription>Manage your generated verification keys</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Key</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Time Left</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Status</th>
                <th className="text-right py-3 px-4 text-sm font-medium text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {keys.map((keyData) => (
                <tr key={keyData.id} className="border-b border-border hover-elevate" data-testid={`key-row-${keyData.id}`}>
                  <td className="py-3 px-4">
                    <code className="text-sm font-mono text-foreground" data-testid={`key-code-${keyData.id}`}>
                      {keyData.key}
                    </code>
                  </td>
                  <td className="py-3 px-4">
                    <span className="text-sm text-foreground" data-testid={`time-left-${keyData.id}`}>
                      {getTimeRemaining(keyData.expiresAt)}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    {getStatusBadge(keyData.status)}
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex justify-end gap-2">
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => copyToClipboard(keyData.key)}
                        data-testid={`button-copy-${keyData.id}`}
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => onDeleteKey(keyData.id)}
                        data-testid={`button-delete-${keyData.id}`}
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}
