import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Shield } from "lucide-react";

interface PrivacyModalProps {
  open: boolean;
  onAccept: () => void;
}

export default function PrivacyModal({ open, onAccept }: PrivacyModalProps) {
  return (
    <Dialog open={open}>
      <DialogContent className="max-w-2xl" onInteractOutside={(e) => e.preventDefault()}>
        <DialogHeader>
          <div className="flex items-center gap-2 mb-2">
            <Shield className="w-5 h-5 text-primary" />
            <DialogTitle>Privacy Policy for Visitors</DialogTitle>
          </div>
          <DialogDescription>
            Please review our privacy policy before using the key system
          </DialogDescription>
        </DialogHeader>
        
        <ScrollArea className="h-[300px] pr-4">
          <div className="space-y-4 text-sm text-foreground">
            <p>
              In order to use this key system, we must collect some non-personally-identifiable 
              information from your browser to ensure the security and integrity of the service.
            </p>
            
            <div className="space-y-2">
              <h4 className="font-semibold text-foreground">Information We Collect</h4>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                <li>Your IP address for session management</li>
                <li>Browser fingerprint for verification purposes</li>
                <li>Key generation timestamps</li>
                <li>Key usage statistics</li>
              </ul>
            </div>
            
            <div className="space-y-2">
              <h4 className="font-semibold text-foreground">How We Use This Information</h4>
              <p className="text-muted-foreground">
                Once you have created a reward session, our API will collect the IP address and 
                unique browser identifier to prevent abuse and ensure fair usage of the key system. 
                This information is used solely for verification purposes.
              </p>
            </div>
            
            <div className="space-y-2">
              <h4 className="font-semibold text-foreground">Data Retention</h4>
              <p className="text-muted-foreground">
                Your IP address and unique browser identifier will be automatically deleted from 
                our server after 7-10 days of inactivity. We do not store any personally identifiable 
                information beyond this period.
              </p>
            </div>
            
            <p className="text-xs text-muted-foreground pt-4">
              This policy is effective as of January 1, 2025.
            </p>
          </div>
        </ScrollArea>
        
        <DialogFooter>
          <Button 
            onClick={onAccept} 
            className="w-full"
            data-testid="button-accept-privacy"
          >
            I Accept
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
