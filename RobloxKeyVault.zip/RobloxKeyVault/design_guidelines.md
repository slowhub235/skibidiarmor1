# Design Guidelines: Roblox Key System Website

## Design Approach: Gaming-Inspired Utility System

**Framework:** Material Design principles adapted for gaming aesthetic with dark-first approach. The utility-focused nature (key generation, verification, tracking) demands clarity and performance over visual flourish.

**Core Philosophy:** Trustworthy, efficient key management with subtle gaming aesthetics. Think Discord meets Stripe - clean, professional, with gaming DNA.

---

## Color Palette

**Dark Mode Primary (Default):**
- Background Base: 220 15% 8%
- Surface Elevated: 220 12% 12%
- Surface Interactive: 220 10% 16%
- Border Subtle: 220 8% 24%

**Accent Colors:**
- Primary (Key Actions): 210 100% 60% (Vibrant blue for trust/tech)
- Success (Active Keys): 145 65% 55% (Green for verified/active)
- Warning (Expiring): 35 90% 60% (Amber for time warnings)
- Error (Invalid): 0 70% 60% (Red for errors/expired)
- Accent Secondary: 270 60% 65% (Purple for premium/special states)

**Text Hierarchy:**
- Primary Text: 220 10% 95%
- Secondary Text: 220 8% 65%
- Tertiary/Muted: 220 6% 45%

---

## Typography

**Font Stack:**
- Primary: 'Inter' via Google Fonts (system UI, clean readability)
- Monospace: 'JetBrains Mono' for keys, codes, IP addresses (technical data)

**Scale:**
- Hero/Page Title: text-4xl font-bold (36px)
- Section Headers: text-2xl font-semibold (24px)
- Card Titles: text-lg font-medium (18px)
- Body: text-base (16px)
- Small/Meta: text-sm (14px)
- Key Codes: text-sm font-mono tracking-wider

---

## Layout System

**Spacing Units:** Use Tailwind units of **2, 4, 6, 8, 12, 16** for consistent rhythm (e.g., p-4, gap-6, mt-8, py-12)

**Container Strategy:**
- Max width: max-w-6xl mx-auto
- Page padding: px-4 md:px-6 lg:px-8
- Section spacing: py-12 md:py-16

**Grid System:**
- Key cards: Single column on mobile, up to 2-3 columns on desktop when showing multiple keys
- Progress steps: Horizontal flow with connecting lines
- Stats/Info: 2-column grid for key metrics (keys remaining, IP, etc.)

---

## Component Library

### Navigation/Header
- Fixed header with logo/brand on left
- Minimal navigation (just branding + user status)
- Subtle border-bottom for separation
- Height: h-16, backdrop-blur effect

### Key Generation Card (Primary CTA)
- Large, elevated card (shadow-xl) with gradient border accent
- Progress indicator: Step counter with visual progress bar (0/2, 1/2, 2/2)
- Prominent "GET A NEW KEY" button: Full-width or prominent size, primary color
- Current status display with icon indicators

### Active Keys Table/List
- Compact table design with columns: Key Code | Time Left | Status | Actions
- Monospace font for key codes
- Color-coded status badges (active=green, expiring=amber, expired=red)
- Time remaining with countdown timer
- Copy button for each key code
- Empty state when no keys: Centered illustration placeholder with helpful message

### Privacy Modal
- Overlay with backdrop-blur and dark overlay (bg-black/60)
- Centered modal card with clear typography
- Scrollable content area for policy text
- Sticky "I Accept" button at bottom
- Close option (X icon top-right)

### Buttons
- Primary: bg-primary with hover lift effect (shadow-lg)
- Outline variant for secondary actions: border-2 with transparent bg
- When outline buttons on dark backgrounds: Add backdrop-blur-sm bg-black/20 for visibility
- Consistent padding: px-6 py-3 for normal, px-8 py-4 for hero CTAs

### Status Indicators
- Pills/badges with rounded-full design
- Icon + text combination
- Size: px-3 py-1 text-xs for compact, px-4 py-2 text-sm for prominent

### Cards
- Rounded-lg or rounded-xl corners
- Subtle shadow (shadow-md) with hover elevation (shadow-lg)
- Border: border border-white/5 for subtle definition
- Padding: p-6 for content areas

---

## Page Sections

### Hero/Main Area (Above Fold)
- Brand header with tagline: "Thanhub Freemium" or custom brand name
- Large progress tracker card showing current verification progress
- Minimal decorative elements - focus on functionality
- **No large hero image** - this is a utility app, not marketing

### Key Dashboard Section
- Grid of active keys with all relevant info
- Quick actions (copy, delete, refresh)
- Filter/sort options if many keys
- Real-time countdown timers

### Footer
- Privacy policy link
- Contact/support
- Minimal branding
- Height: Compact (py-8)

---

## Interactions & Micro-animations

**Minimize Animations** - Only use where functional:
- Button hover: Subtle scale (scale-105) and shadow increase
- Progress transitions: Smooth width animations on progress bars
- Countdown timers: No animation, just text updates
- Modal entry: Simple fade-in (no elaborate transitions)
- Copy feedback: Brief toast notification or checkmark flash

**Loading States:**
- Skeleton screens for key table
- Spinner for key generation process
- Disabled state for buttons during processing

---

## Trust & Security Elements

- IP address display (shows transparency)
- Clear expiration timers (builds urgency and trust)
- Privacy policy prominently linked
- Session information visible
- Key count limits displayed clearly

---

## Accessibility

- All interactive elements keyboard accessible
- Focus states visible (ring-2 ring-primary)
- Sufficient color contrast (WCAG AA minimum)
- Alt text for any icons used standalone
- Proper heading hierarchy (h1 → h2 → h3)

---

## Images

**No images required** for this utility application. All visual interest comes from:
- Color-coded status indicators
- Gradient accents on cards
- Clean typography hierarchy
- Iconography from Heroicons (outline style for consistency)

Focus on data clarity and functional design over decorative imagery.